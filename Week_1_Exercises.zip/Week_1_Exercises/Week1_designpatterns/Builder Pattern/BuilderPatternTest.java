/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cts_assesment;

/**
 *
 * @author HP
 */
public class BuilderPatternTest {
    public static void main(String[] args) {
        // Creating different configurations of Computer using Builder pattern
        Computer gamingComputer = new Computer.Builder("Intel i9", "32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setOperatingSystem("Windows 10")
                .build();

        Computer officeComputer = new Computer.Builder("Intel i5", "16GB")
                .setStorage("512GB SSD")
                .setOperatingSystem("Windows 10")
                .build();

        Computer basicComputer = new Computer.Builder("Intel i3", "8GB")
                .setStorage("256GB SSD")
                .build();

        // Printing the configurations
        System.out.println("Gaming Computer: " + gamingComputer);
        System.out.println("Office Computer: " + officeComputer);
        System.out.println("Basic Computer: " + basicComputer);
    }
}
