/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week_1_Exercises;

/**
 *
 * @author HP
 */
import java.util.HashMap;
import java.util.Map;

public class ProxyImage implements Image {
    private String fileName;
    private RealImage realImage;
    private static Map<String, RealImage> cache = new HashMap<>();

    public ProxyImage(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void display() {
        if (realImage == null) {
            realImage = cache.get(fileName);
            if (realImage == null) {
                realImage = new RealImage(fileName);
                cache.put(fileName, realImage);
            }
        }
        realImage.display();
    }
}
