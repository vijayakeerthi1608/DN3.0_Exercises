/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week_1_Exercises;

/**
 *
 * @author HP
 */
public class CreditCardPayment implements PaymentStrategy{
    private String cardNumber;
    private String cardHolderName;
    private String cvv;
    private String expiryDate;
    CreditCardPayment(String cardNumber,String cardHolderName,String cvv,String expiryDate){
    this.cardNumber=cardNumber;
    this.cardHolderName=cardHolderName;
    this.cvv=cvv;
    this.expiryDate=expiryDate;
    }
    @Override
    public void pay(double amount){
        System.out.println(amount+" paied with credit card");
    }
}
