/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Week_1_Exercises;

/**
 *
 * @author HP
 */
public class PayPalPayment implements PaymentStrategy {
   
    private String email;
    private String password;
    PayPalPayment(String email,String password){
        this.email=email;
        this.password=password;
    }
    
    @Override
    public void pay(double amount){
        System.out.println(amount+" paied by PayPal");
    }
}
