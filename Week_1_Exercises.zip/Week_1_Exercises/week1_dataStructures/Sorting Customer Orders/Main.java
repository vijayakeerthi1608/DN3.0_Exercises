public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("O001", "Alice", 250.75),
            new Order("O002", "Bob", 150.50),
            new Order("O003", "Charlie", 350.00),
            new Order("O004", "David", 125.00),
            new Order("O005", "Eve", 300.40)
        };

        // Using Bubble Sort
        System.out.println("Orders before Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
        
        BubbleSort.bubbleSort(orders);
        
        System.out.println("\nOrders after Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }

        // Resetting orders array for Quick Sort
        orders = new Order[] {
            new Order("O001", "Alice", 250.75),
            new Order("O002", "Bob", 150.50),
            new Order("O003", "Charlie", 350.00),
            new Order("O004", "David", 125.00),
            new Order("O005", "Eve", 300.40)
        };

        // Using Quick Sort
        System.out.println("\nOrders before Quick Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
        
        QuickSort.quickSort(orders, 0, orders.length - 1);
        
        System.out.println("\nOrders after Quick Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
