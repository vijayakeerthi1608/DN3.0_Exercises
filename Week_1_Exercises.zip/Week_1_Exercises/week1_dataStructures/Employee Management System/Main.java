public class Main {
    public static void main(String[] args) {
        EmployeeManagement ems = new EmployeeManagement(5);

        // Adding employees
        ems.addEmployee(new Employee("E001", "Alice", "Developer", 60000));
        ems.addEmployee(new Employee("E002", "Bob", "Manager", 80000));
        ems.addEmployee(new Employee("E003", "Charlie", "Analyst", 50000));

        // Traversing employees
        System.out.println("Employees list:");
        ems.traverseEmployees();

        // Searching for an employee
        Employee emp = ems.searchEmployee("E002");
        if (emp != null) {
            System.out.println("Employee found: " + emp);
        } else {
            System.out.println("Employee not found.");
        }

        // Deleting an employee
        ems.deleteEmployee("E002");
        System.out.println("Employees list after deletion:");
        ems.traverseEmployees();
    }
}
