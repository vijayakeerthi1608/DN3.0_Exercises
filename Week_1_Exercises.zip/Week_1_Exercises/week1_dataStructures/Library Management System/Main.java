public class Main {
    public static void main(String[] args) {
        LibraryManagement library = new LibraryManagement(5);

        // Adding books
        library.addBook(new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book("B002", "To Kill a Mockingbird", "Harper Lee"));
        library.addBook(new Book("B003", "1984", "George Orwell"));
        library.addBook(new Book("B004", "Pride and Prejudice", "Jane Austen"));
        library.addBook(new Book("B005", "The Catcher in the Rye", "J.D. Salinger"));

        // Traversing books
        System.out.println("Books list:");
        library.traverseBooks();

        // Linear search for a book by title
        Book book = library.linearSearchByTitle("1984");
        if (book != null) {
            System.out.println("Book found using linear search: " + book);
        } else {
            System.out.println("Book not found using linear search.");
        }

        // Binary search for a book by title
        book = library.binarySearchByTitle("1984");
        if (book != null) {
            System.out.println("Book found using binary search: " + book);
        } else {
            System.out.println("Book not found using binary search.");
        }
    }
}
