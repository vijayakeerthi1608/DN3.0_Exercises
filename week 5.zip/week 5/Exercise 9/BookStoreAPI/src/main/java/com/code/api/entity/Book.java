package com.code.api.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "books")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotNull(message = "Title cannot be null")
    @Size(min = 10, max = 50, message = "Title size should be between 10 to 50 characters")
    @Column(name = "title", nullable = false, unique = true, length = 50)
    private String title;

    @NotNull(message = "Author cannot be null")
    @Size(min = 3, max = 50, message = "Author size should be between 3 to 50 characters")
    @Column(name = "author", nullable = false, length = 50)
    private String author;

    @Min(value = 1, message = "Price should be greater than 1")
    @Column(name = "price", nullable = false)
    private double price;

    @NotNull(message = "ISBN cannot be null")
    @Size(min = 13, max = 13, message = "ISBN should be exactly 13 characters")
    @Column(name = "isbn", nullable = false, unique = true, length = 13)
    private String isbn;

    @Version
    private Long version;

    // Additional Constructor for Creating Books without ID (useful for DTOs or New Book Creation)
    public Book(String title, String author, double price, String isbn) {
        this.title = title;
        this.author = author;
        this.price = price;
        this.isbn = isbn;
    }

	public String getIsbn() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setAuthor(String author2) {
		// TODO Auto-generated method stub
		
	}

	public void setIsbn(String isbn2) {
		// TODO Auto-generated method stub
		
	}

	public void setTitle(String title2) {
		// TODO Auto-generated method stub
		
	}

	public Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setPrice(Object price2) {
		// TODO Auto-generated method stub
		
	}
}
